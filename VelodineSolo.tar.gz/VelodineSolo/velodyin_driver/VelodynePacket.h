#ifndef VELODYNEPACKET_H
#define VELODYNEPACKET_H
#include <ctime>
#include <chrono>
#include <vector>

struct VelodynePacket{
    double stamp; /// other time
    uint8_t data[1206];

};

struct VelodyneScan{
    double stamp; /// other time
    std::vector<VelodynePacket> packets;

};


#endif // VELODYNEPACKET_H

