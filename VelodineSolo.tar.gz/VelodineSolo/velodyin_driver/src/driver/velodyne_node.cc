/*
 *  Copyright (C) 2012 Austin Robot Technology, Jack O'Quin
 * 
 *  License: Modified BSD Software License Agreement
 *
 *  $Id$
 */

/** \file
 *
 *  ROS driver node for the Velodyne 3D LIDARs.
 */


#include "driver.h"
#include <iostream>
int main(int argc, char** argv)
{

/// iobost steam
  // start the driver
  velodyne_driver::VelodyneDriver dvr;
std::cout<<"pollin\n";
  // loop until shut down or end of file







  //... populate cloud
#if DISPLAY
pcl::visualization::CloudViewer viewer ("Simple Cloud Viewer");
#endif



velodyne_rawdata::VPointCloud::Ptr outMsg =dvr.poll() ;
#if DISPLAY

  while( outMsg !=NULL || !viewer.wasStopped ())
    {
#else
while( outMsg !=NULL )
  {
#endif
#if DISPLAY
      pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
      cloud->height = 1;
      cloud->width = outMsg->width;
      for (int i=0;i<outMsg->points.size() ; i++ )
      {



          pcl::PointXYZ point;

          point.x = outMsg->points[i].x;
          point.y = outMsg->points[i].y;
          point.z = outMsg->points[i].z;

        // std::cout <<"value "<< point.x  <<" "<< point.y  <<" "<< point.z  <<" "<< std::endl;
          cloud->points.push_back(point);

      }
      viewer.showCloud (cloud);
#endif
outMsg =dvr.poll() ;
    }

  return 0;
}
