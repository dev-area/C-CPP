/* -*- mode: C++ -*- */
/*
 *  Copyright (C) 2012 Austin Robot Technology, Jack O'Quin
 * 
 *  License: Modified BSD Software License Agreement
 *
 *  $Id$
 */

/** \file
 *
 *  ROS driver interface for the Velodyne 3D LIDARs
 */

#ifndef _VELODYNE_DRIVER_H_
#define _VELODYNE_DRIVER_H_ 1

#include <string>
#include <boost/shared_ptr.hpp>

#include "../../include/velodyne_driver/input.h"
#include "../lib/convert.h"
#include "vtkPacketFileWriter.h"

namespace velodyne_driver
{

class VelodyneDriver
{
public:

  VelodyneDriver();
  ~VelodyneDriver() {}

  velodyne_rawdata::VPointCloud::Ptr poll(void);

private:

vtkPacketFileWriter pcapWriter;

  velodyne_pointcloud::Convert conv_;
  ///Callback for dynamic reconfigure


  ///Pointer to dynamic reconfigure service srv_


  // configuration parameters
  struct
  {
    std::string frame_id;            ///< tf frame ID
    std::string model;               ///< device model name
    int npackets;                 ///< number of packets to collect
    double rpm;                      ///< device rotation rate (RPMs)
    int cut_angle;                   ///< cutting angle in 1/100°
    double time_offset;              ///< time in seconds added to each velodyne time stamp
    double angle_start;
    double angle_end;
  } config_;



    boost::shared_ptr<Input> input_;
//  /** diagnostics updater */

//  double diag_min_freq_;
//  double diag_max_freq_;

};

} // namespace velodyne_driver

#endif // _VELODYNE_DRIVER_H_
