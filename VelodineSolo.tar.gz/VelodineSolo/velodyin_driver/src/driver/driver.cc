/*
 *  Copyright (C) 2007 Austin Robot Technology, Patrick Beeson
 *  Copyright (C) 2009-2012 Austin Robot Technology, Jack O'Quin
 * 
 *  License: Modified BSD Software License Agreement
 *
 *  $Id$
 */

/** \file
 *
 *  ROS driver implementation for the Velodyne 3D LIDARs
 */

#include <string>
#include <cmath>

#include <pcap.h>
#include <netinet/in.h>
#include "driver.h"

namespace velodyne_driver
{

VelodyneDriver::VelodyneDriver()
{

//conv_= new velodyne_pointcloud::Convert("Path");
velodyne_pointcloud::Convert c("cc");
conv_=c; //class conv convert to pointcloud



pcapWriter.Open("test.pcap"); // file name to save need to be as option

  double packet_rate;                   // packet frequency (Hz)
  std::string model_full_name;
//  if ((config_.model == "64E_S2") ||
//      (config_.model == "64E_S2.1"))    // generates 1333312 points per second
//    {                                   // 1 packet holds 384 points
//      packet_rate = 3472.17;            // 1333312 / 384
//      model_full_name = std::string("HDL-") + config_.model;
//    }
//  else if (config_.model == "64E")
//    {
//      packet_rate = 2600.0;
//      model_full_name = std::string("HDL-") + config_.model;
//    }
//  else if (config_.model == "32E")
//    {
//      packet_rate = 1808.0;
//      model_full_name = std::string("HDL-") + config_.model;
//    }
//    else if (config_.model == "32C")
//    {
//      packet_rate = 1808.0;
//      model_full_name = std::string("VLP-") + config_.model;
//    }
//  else if (config_.model == "VLP16")
//    {
      packet_rate = 754;             // 754 Packets/Second for Last or Strongest mode 1508 for dual (VLP-16 User Manual)
      model_full_name = "VLP-16";
//    }
//  else
//    {
//      ROS_ERROR_STREAM("unknown Velodyne LIDAR model: " << config_.model);
//      packet_rate = 2600.0;
//    }
  std::string deviceName(std::string("Velodyne ") + model_full_name);

//  private_nh.param("rpm", config_.rpm, 600.0);
  config_.rpm=600;
//  ROS_INFO_STREAM(deviceName << " rotating at " << config_.rpm << " RPM");
  double frequency = (config_.rpm / 60.0);     // expected Hz rate

  // default number of packets for each scan is a single revolution
  // (fractions rounded up)
  config_.npackets = (int) ceil(packet_rate / frequency);
//  private_nh.getParam("npackets", config_.npackets);
//  ROS_INFO_STREAM("publishing " << config_.npackets << " packets per scan");

  std::string dump_file =
          "";
//  private_nh.param("pcap", dump_file, std::string(""));

  double cut_angle=0;
//  private_nh.param("cut_angle", cut_angle, -0.01);
  if (cut_angle < 0.0)
  {
//    ROS_INFO_STREAM("Cut at specific angle feature deactivated.");
  }
  else if (cut_angle < (2*M_PI))
  {
//      ROS_INFO_STREAM("Cut at specific angle feature activated. "
//        "Cutting velodyne points always at " << cut_angle << " rad.");
  }
  else
  {
//    ROS_ERROR_STREAM("cut_angle parameter is out of range. Allowed range is "
//    << "between 0.0 and 2*PI or negative values to deactivate this feature.");
    cut_angle = -0.01;
  }

  // Convert cut_angle from radian to one-hundredth degree, 
  // which is used in velodyne packets
  config_.cut_angle = int((cut_angle*360/(2*M_PI))*100);
  /// start angle and angle end are which area of the scan to save
    config_.angle_start =1;
    config_.angle_end = 5000;
  int udp_port = 2368;


  // open Velodyne input device or file
  if (dump_file != "")                  // have PCAP file?
    {
      // read data from packet capture file
      input_.reset(new velodyne_driver::InputPCAP( udp_port,
                                                  packet_rate, dump_file));
    }
  else
    {
      // read data from live socket
      input_.reset(new velodyne_driver::InputSocket( udp_port));
    }


}

/** poll the device
 *
 *  @returns true unless end of file reached
 */
velodyne_rawdata::VPointCloud::Ptr VelodyneDriver::poll(void)
{
  // Allocate a new shared pointer for zero-copy sharing with other nodelets.

 VelodyneScan scan;

//    std::cout<<"poll "<<__LINE__<<std::endl;


//std::cout<<"config_.cut_angle "<<config_.npackets<<std::endl;
  if( config_.cut_angle >= 0) //Cut at specific angle feature enabled
  {


    scan.packets.reserve(config_.npackets);
    int inserted_package = 0 ;
    VelodynePacket tmp_packet;
    while(true)
    {
      while(true)
      {
        int rc = input_->getPacket(&tmp_packet, config_.time_offset);
        if (rc == 0) break;       // got a full packet?
        if (rc < 0) return NULL; // end of file reached?
      }


      static int last_azimuth = -1;
      // Extract base rotation of first block in packet
      std::size_t azimuth_data_pos = 100*0+2;
      int azimuth = *( (u_int16_t*) (&tmp_packet.data[azimuth_data_pos]));

       if(config_.angle_start<azimuth && config_.angle_end>azimuth)
       {
        scan.packets.push_back(tmp_packet);

         inserted_package++;
       }
      // Handle overflow 35999->0
      if(azimuth<last_azimuth)
        last_azimuth-=36000;
      // Check if currently passing cut angle
      if(   last_azimuth != -1
         && last_azimuth < config_.cut_angle
         && azimuth >= config_.cut_angle )
      {

        last_azimuth = azimuth;
        break; // Cut angle passed, one full revolution collected
      }
      last_azimuth = azimuth;
    }
  }
  else // standard behaviour
  {
      //std::cout<<"no cut\n";
  // Since the velodyne delivers data at a very high rate, keep
  // reading and publishing scans as fast as possible.
    scan.packets.resize(config_.npackets);
    for (int i = 0; i < config_.npackets; ++i)
    {
      while (true)
        {
          // keep reading until full packet received
          int rc = input_->getPacket(&scan.packets[i], config_.time_offset);
          if (rc == 0) break;       // got a full packet?
          if (rc < 0) return NULL; // end of file reached?
        }
    }
  }

  for (int i=0;i<scan.packets.size() ;i++)
  {
      pcapWriter.WritePacket(scan.packets[i].data,1206);
  }
  /// write to pcap option

//std::cout<<"convert scan " <<scan.packets.size()<<std::endl;

return conv_.processScan(&scan);



}
} // namespace velodyne_driver
