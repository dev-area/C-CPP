
QA Training: C++ for C Programmers

This floppy disk contains three files:

  /1/ qareadme.txt
	(This file)

  /2/ qacpppg.zip
	Which contains all your lab work and the Visual C++
	project files for the labs. You can unzip this to 
	any location you wish but you must retain the 
	directory structure. 

  /3/ qastdlib.zip
	Which contains the source and documentation for the
	QA teaching subset of the C++ standard library.
	If you plan to reuse the Visual C++ project files
	you must unzip this to the root of C: 

Thank you for choosing QA Training
