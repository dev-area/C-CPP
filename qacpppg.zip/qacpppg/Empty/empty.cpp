
// This is a completely empty project file
// It is included so that can easily create
// your own projects which use qa::stdlib++

#include <iostream.h>
#include <qa/string.hpp>

using namespace qa;

int main()
{
	string empty("Empty");
	cout << empty << endl;
	return 0;
}
