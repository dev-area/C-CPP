#include "Widget.h"
#include <sstream>

using namespace std;

string Widget::print() const {
	// #3 Use Range-for to iterate the vector.
	//    Use auto to type the element variable.
	//    Stream the integer elements into an ostringstream.
	//    Call .str() on the ostringstream to generate a string.
	// Your code here ...
	ostringstream s;
	for (auto element : v) {
		s << element << " : ";
	}
	return s.str();
}

// #4 Modify getValue() with trailing return, and use vector bounds-checked .at()
auto Widget::getValue(int index) const -> Value {
	return v.at(index);
}

// #4 Modify getValueWithString() with 
//		- trailing return
//		- anonymous brace-construction return statement	of the form: return { ... };
auto Widget::getValueWithString(int index) const -> std::pair<Value, std::string> {
	 return { getValue(index), to_string(getValue(index)) };
}