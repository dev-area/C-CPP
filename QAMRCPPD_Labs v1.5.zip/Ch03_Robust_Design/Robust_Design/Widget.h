#pragma once
#include <string>
#include <utility> // for pair
// #1 Add header file for vector

class Widget {
public:
	enum Value {zero,one,two,three,four,five,six,seven,eight,nine};
	Value getValue(int index) const;
	std::pair<Value,std::string> getValueWithString(int index) const;
	std::string print() const;
private:
	// #1 Change the Value array to a vector of Value's
	// #2 Provide in-class initialisation with a braced-list of all Value members
	Value v[1] = { zero };

};
