#include "Widget.h"
#include <sstream>

using namespace std;

string Widget::print() const {
	// #3 Use Range-for to iterate the vector.
	//    Use auto to type the element variable.
	//    Stream the integer elements into an ostringstream.
	//    Call .str() on the ostringstream to generate a string.
	// Your code here ...

	return "something";
}

// #4 Modify getValue() with trailing return, and use vector bounds-checked .at()
Widget::Value Widget::getValue(int index) const {
	return v[index];
}

// #4 Modify getValueWithString() with 
//		- trailing return
//		- anonymous brace-construction return statement	of the form: return { ... };
std::pair<Widget::Value, std::string> Widget::getValueWithString(int index) const {
	return std::pair<Value, std::string>(getValue(index), to_string(getValue(index)));
}