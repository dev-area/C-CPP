//====================================================================
// File:        strong_Typedef.hpp
// Description: Declaration of strongTypeDef class
//====================================================================

#pragma once

// Place your templated strongTypeDef class definition here




// Place your dummy structs for Length and Area types here




// Place your typedefs defining Length and Area alias types here



